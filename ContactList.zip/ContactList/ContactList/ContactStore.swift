//
//  ContactStore.swift
//  ContactList
//
//  Created by Vahid on 14/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import UIKit
import CoreData

enum ContactError: ErrorType {
    case ContactCreationError
}

class ContactStore {
    
    let coreDataStack = CoreDataStack()
    
    let session: NSURLSession = {
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        return NSURLSession(configuration: config)
    }()
    
    func processContactsRequest(data data: NSData?, error: NSError?) -> ContactsResult {
        guard let jsonData = data else {
            return .Failure(error!)
        }
        
        return JsonApi.contactsFromJSONData(jsonData,
                                            inContext: self.coreDataStack.managedObjectContext)
    }
        
    
    func fetchMainQueueContacts(predicate predicate: NSPredicate? = nil,
                                          sortDescriptors: [NSSortDescriptor]? = nil) throws -> [Contact] {
        
        let fetchRequest = NSFetchRequest(entityName: "Contact")
        fetchRequest.sortDescriptors = sortDescriptors
        
        let mainQueueContext = self.coreDataStack.managedObjectContext
        var mainQueueContacts: [Contact]?
        var fetchRequestError: ErrorType?
        mainQueueContext.performBlockAndWait({
            do {
                mainQueueContacts = try mainQueueContext.executeFetchRequest(fetchRequest) as? [Contact]
            }
            catch let error {
                fetchRequestError = error
            }
        })
        
        guard let contacts = mainQueueContacts else {
            throw fetchRequestError!
        }
        
        return contacts
    }
    
    func fetchContacts(completion completion: (ContactsResult) -> Void) {
        
        let url = NSURL(string: JsonApi.getUrl())
        let request = NSURLRequest(URL: url!)
        let task = session.dataTaskWithRequest(request, completionHandler: {
            (data, response, error) -> Void in
            
            var result = self.processContactsRequest(data: data, error: error)

            if case let .Success(contacts) = result {
                
                let queueContext = self.coreDataStack.managedObjectContext
                queueContext.performBlockAndWait({
                    try! queueContext.obtainPermanentIDsForObjects(contacts)
                })
                let objectIDs = contacts.map{ $0.objectID }
                let predicate = NSPredicate(format: "self IN %@", objectIDs)
                let sortByName = NSSortDescriptor(key: "contactID", ascending: true)
                
                do {
                    try self.coreDataStack.saveContext()
                    
                    let mainQueueContacts = try self.fetchMainQueueContacts(predicate: predicate,
                        sortDescriptors: [sortByName])
                    result = .Success(mainQueueContacts)
                }
                catch let error {
                    result = .Failure(error)
                }
            }
            
            completion(result)
        })
        task.resume()
    }
    func fetchContactsWithSort(sort: Bool , contacts: [Contact], completion: (ContactsResult) -> Void) {
        
        var resultContacts = ContactsResult.Success(contacts)
        
                let queueContext = self.coreDataStack.managedObjectContext
                queueContext.performBlockAndWait({
                    try! queueContext.obtainPermanentIDsForObjects(contacts)
                })
                let objectIDs = contacts.map{ $0.objectID }
                let predicate = NSPredicate(format: "self IN %@", objectIDs)
                let sortByName = NSSortDescriptor(key: "fullName", ascending: sort)
                
                do {
                    try self.coreDataStack.saveContext()
                    
                    let mainQueueContacts = try self.fetchMainQueueContacts(predicate: predicate,
                        sortDescriptors: [sortByName])
                    resultContacts = .Success(mainQueueContacts)
                }
                catch let error {
                    resultContacts = .Failure(error)
                }
        
            completion(resultContacts)
    }
    
    func offlineContacts( completion: (ContactsResult) -> Void) {
        
        var resultContacts : ContactsResult
        
        let moc = self.coreDataStack.managedObjectContext
        let contactsFetch = NSFetchRequest(entityName: "Contact")
        
        do {
            let fetchedContacts = try moc.executeFetchRequest(contactsFetch) as! [Contact]
            print(fetchedContacts.count)
            print(fetchedContacts)
            if fetchedContacts.count > 0 {
                resultContacts = .Success(fetchedContacts)
            }
            else {
                resultContacts = .Failure(FetchError.ErrorFetchingResults)
            }

        } catch let error {
            resultContacts = .Failure(error)
        }
        completion(resultContacts)
    }
    
}
