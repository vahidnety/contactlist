//
//  SortTableViewController.swift
//  ContactList
//
//  Created by Vahid on 20/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import UIKit
import CoreData


class SortTableViewController: UITableViewController {
    var selectedIndex: Int = 0
    @IBAction func Done(sender: AnyObject) {
        let check = String(format: "%d",selectedIndex)
        NSUserDefaults.standardUserDefaults().setObject(check, forKey: "Sort")
        NSUserDefaults.standardUserDefaults().synchronize()
        NSNotificationCenter.defaultCenter().postNotificationName("load", object: nil)
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.rowHeight = UITableViewAutomaticDimension

    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    func resetChecks() {
        for i in (0..<self.tableView.numberOfSections) {
            for j in (0..<self.tableView.numberOfRowsInSection(i)) {
                if let cell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: j, inSection: i)) {
                    cell.accessoryType = .None
                }
            }
        }
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        self.resetChecks()
        self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        if let cell = self.tableView.cellForRowAtIndexPath(indexPath) {
            if cell.accessoryType == .None
            {
                selectedIndex=indexPath.row
                cell.accessoryType = .Checkmark
            }
            else
            {
                cell.accessoryType = .None
            }
        }
    }
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath)
    {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults()
        let aString = defaults.valueForKey("Sort") as? String
        let cellIndex:Int? = Int(aString!)
        if indexPath.row == cellIndex {
            selectedIndex=indexPath.row
            cell.accessoryType = .Checkmark
        }
        else
        {
            cell.accessoryType = .None
        }
        
    }
    
}
