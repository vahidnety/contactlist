//
//  Contacts.swift
//  ContactList
//
//  Created by Vahid on 14/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import Foundation
import CoreData


class Contacts: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
