//
//  ContactsDataSource.swift
//  ContactList
//
//  Created by Vahid on 14/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import UIKit
import CoreData

class ContactsDataSource: NSObject, UITableViewDataSource {
    
    var contacts: [Contact] = []

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return contacts.count
    }
    
    func tableView(tableView: UITableView,
                   cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("contactCellReuseIdentifier",
                                                               forIndexPath: indexPath) as! ContactCell
        let contact = contacts[indexPath.row]
        cell.updateWithContact(contact)
        return cell
    }
}
