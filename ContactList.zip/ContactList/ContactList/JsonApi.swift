//
//  JsonApi.swift
//  ContactList
//
//  Created by Vahid on 15/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import Foundation
import CoreData

enum ContactsResult {
    case Success([Contact]!)
    case Failure(ErrorType)
}

enum FetchError: ErrorType {
    case ErrorFetchingResults
}

class JsonApi {
    
    class func getUrl() -> (String){
        let jsonUrl = "http://jsonplaceholder.typicode.com/users"
        return jsonUrl
    }
    
    class func contactsFromJSONData(data: NSData,
                                    inContext context: NSManagedObjectContext) -> ContactsResult {
        do {
            let jsonObject: AnyObject = try NSJSONSerialization.JSONObjectWithData(data, options: [])
            
            let contactsArray = jsonObject as? [[String:AnyObject]]
            
            var finalContacts = [Contact]()
            for contactJSON in contactsArray! {
                if let contact = contactFromJSONObject(contactJSON , inContext: context)
                {
                    finalContacts.append(contact)
                }
            }
            
            if finalContacts.count == 0 && contactsArray!.count > 0 {
                //error
                return .Failure(FetchError.ErrorFetchingResults)
            }
            return .Success(finalContacts)
        }
        catch let error {
            return .Failure(error)
        }
    }
    
    private class func contactFromJSONObject(json: [String : AnyObject],
                                             inContext context: NSManagedObjectContext) -> Contact? {
        guard let
            fullName = json["name"] as? String,
            emailAddress = json["email"] as? String,
            contactID = json["id"]?.intValue,
        
            userName = json["username"] as? String,
            website = json["website"] as? String,
            phone = json["phone"] as? String,
            company = json["company"] as? [String:AnyObject],
            address = json["address"] as? [String:AnyObject]

            else {
                return nil
        }

        let fetchRequest = NSFetchRequest(entityName: "Contact")
        let predicate = NSPredicate(format: "contactID == %d", contactID)
        
        fetchRequest.predicate = predicate
        
        var fetchedContacts: [Contact]!
        context.performBlockAndWait() {
            fetchedContacts = try! context.executeFetchRequest(fetchRequest) as! [Contact]
        }
        var fetchedDetails: [Detail]!
        context.performBlockAndWait() {
            fetchedDetails = try! context.executeFetchRequest(fetchRequest) as! [Detail]
        }
        
        if fetchedContacts.count > 0 &&  fetchedDetails.count > 0{
            return fetchedContacts.first
        }
        var detail: Detail!
        context.performBlockAndWait({ () -> Void in
            detail = NSEntityDescription.insertNewObjectForEntityForName("Detail",
                inManagedObjectContext: context) as! Detail
            
            detail.address = address
            detail.company = company
            detail.username = userName
            detail.website = website
            detail.phone = phone
        })
        var contact: Contact!
        context.performBlockAndWait({ () -> Void in
            contact = NSEntityDescription.insertNewObjectForEntityForName("Contact",
                inManagedObjectContext: context) as! Contact
            contact.contactID = contactID
            contact.fullName = fullName
            contact.emailAddress = emailAddress
            contact.details=NSSet(objects: detail)
        })
        return contact
    }
}
