//
//  ViewController.swift
//  ContactList
//
//  Created by Vahid on 13/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import UIKit
import Foundation
import CoreData

class ViewController: UIViewController,UITableViewDelegate {
    var store: ContactStore!
    let contactsDataSource = ContactsDataSource()
    
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.spinner.startAnimating()
        self.label.hidden=false
        
        self.startFetching()
    }
    func startFetching() {
        store.fetchContacts() {
            (contactsResult) -> Void in
            
            NSOperationQueue.mainQueue().addOperationWithBlock() {
                switch contactsResult {
                case let .Success(contacts):
                    print("Successfully found \(contacts.count) contacts.")
                    self.contactsDataSource.contacts = contacts
                    self.showTable()
                case let .Failure(error):
                    self.contactsDataSource.contacts.removeAll()
                    print("Error fetching contacts: \(error)")
                    self.showAlert(error)
                }
            }
        }
    }
    func offlineFetching() {
        store.offlineContacts() {
            (contactsResult) -> Void in
            
            NSOperationQueue.mainQueue().addOperationWithBlock() {
                switch contactsResult {
                case let .Success(contacts):
                    print("Successfully found \(contacts.count) contacts.")
                    self.contactsDataSource.contacts = contacts
                    self.showTable()
                case let .Failure(error):
                    self.contactsDataSource.contacts.removeAll()
                    print("Error fetching contacts: \(error)")
                    self.showAlert(error)
                }
            }
        }
    }

    func showAlert(error: ErrorType) {
        dispatch_async(dispatch_get_main_queue(), {
            let alertController = UIAlertController(
                title: "Error!",
                message: (error as NSError).localizedDescription,
                preferredStyle: UIAlertControllerStyle.Alert
            )
            let tryAction = UIAlertAction(
            title: "Try again", style: UIAlertActionStyle.Default) { (action) in
                self.startFetching()
            }
            let offlineAction = UIAlertAction(
            title: "Offline Access", style: UIAlertActionStyle.Default) { (action) in
                self.offlineFetching()
            }

            alertController.addAction(tryAction)
            alertController.addAction(offlineAction)

            self.presentViewController(alertController, animated: true, completion: nil)
            return
        })
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showTable()
    {
        dispatch_async(dispatch_get_main_queue(), {
            self.spinner.stopAnimating()
            self.label.hidden=true
            self.performSegueWithIdentifier("showContacts", sender: self)
            return
        })
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showContacts" {
            let navController = segue.destinationViewController as! UINavigationController
            let contactController = navController.topViewController as! ContactsViewController
            contactController.store = store
            contactController.contactsDataSource.contacts = self.contactsDataSource.contacts
        }
    }
    
}

