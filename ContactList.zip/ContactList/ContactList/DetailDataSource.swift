//
//  ContactsDataSource.swift
//  ContactList
//
//  Created by Vahid on 19/07/2016.
//  Copyright © 2016 Vahid. All rights reserved.
//

import UIKit
import CoreData

class DetailDataSource: NSObject, UITableViewDataSource {
    
    var details: Detail!

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return 5
    }
    
    func tableView(tableView: UITableView,
                   cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("detailCellReuseIdentifier",
                                                               forIndexPath: indexPath) as! DetailCell
        var cellContent: [String]?

        if indexPath.row == 0 {
            let username = String(format:"\n%@\n",(details.username)!)
            cellContent = [username,"USERNAME" ]
        }
        else if indexPath.row == 1 {
            let phone = String(format:"\n%@\n",(details.phone)!)
            cellContent = [phone,"PHONE"]
        }
        else if indexPath.row == 2 {
            let address = String(format:"\n%@ %@\n%@, %@\n" ,
                                 String(details.address!["suite"]!),
                                 String(details.address!["street"]!),
                                 String(details.address!["city"]!),
                                 String(details.address!["zipcode"]!))
            
                            cellContent = [address,"ADDRESS"]
        }
        else if indexPath.row == 3 {
            let website = String(format:"\n%@\n",(details.website)!)
            cellContent = [website,"WEBSITE"]
        }
        else if indexPath.row == 4 {
            let company = String(format:"\n%@\n%@\n%@\n" ,
                                 String(details.company!["name"]!),
                                 String(details.company!["catchPhrase"]!),
                                 String(details.company!["bs"]!))
                            cellContent = [company,"COMPANY"]
        }
        
        cell.updateWithDetail(cellContent)

        return cell
    }
}
